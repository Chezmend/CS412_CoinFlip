
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(5001)) {
            while (true) {
                System.out.println("Waiting for client connection...");

                try (Socket socket = serverSocket.accept()) {
                    System.out.println("Client connected: " + socket.getPort());

                    BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

                    String input = in.readLine();
                    System.out.println("Received: " + input);
                    System.out.println(input.contains("Username:"));
                    System.out.println(input.contains("Amount:"));

                    Model model = new Model();


                    if(input.contains("Username:"))
                    {
                        // parsing the usernames
                        String[] ParseInput = input.split(" ");
                        System.out.println(ParseInput[1]);
                        System.out.println(ParseInput[3]);
                        model.setUser(ParseInput[3], ParseInput[1], 500);
                        out.println("username created");
                    }


                    if(input.contains("Amount:"))
                    {
                        out.println(model.getResults());
                    }

                    if(input.contains("login:"))
                    {
                        out.println("login SUCCESS");
                        String[] ParseInput = input.split(" ");
                        //System.out.println(ParseInput[3] + " " + ParseInput[1]);
                        if(model.verifying(ParseInput[3], ParseInput[1]))
                        {
                            System.out.println("LOGGED IN");
                        }
                        else {
                            System.out.println("FAILED");
                        }
                        out.println("username login");
                    }
                    else
                    {
                        out.println("leaderboard");
                    }
                }
            }
        } catch (IOException e) {
            //System.out.println(e.getMessage());
        }
    }
}
