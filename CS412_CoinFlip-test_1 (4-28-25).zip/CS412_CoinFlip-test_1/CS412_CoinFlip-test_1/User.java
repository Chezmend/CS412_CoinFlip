import org.mindrot.jbcrypt.BCrypt;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import java.sql.*;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.mindrot.jbcrypt.Bcrypt;

public class User {
    private String username;
    private int Amount;
    private String password;

    public User(){

    }
    //https://hashing.mojoauth.com/bcrypt-in-java/
    public void esstablish(String password, String username){
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db")) {
            String cmd = "INSERT INTO players (username, password, amount) VALUES (?, ?)";
            try (PreparedStatement cmdPre = conn.prepareStatement(cmd)) {
                String Hashed = BCrypt.hashpw(password, BCrypt.gensalt());// hashing the password
                System.out.println("password hashed: " + Hashed);

                cmdPre.setString(1, username);
                cmdPre.setString(2, Hashed);

                cmdPre.executeUpdate();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public boolean verifying(String password, String username)
    {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db")) {
            try (PreparedStatement cmdPre = conn.prepareStatement("SELECT username, password FROM players WHERE username = ? LIMIT 1")) {
                cmdPre.setString(1,username);
                try (ResultSet rs = cmdPre.executeQuery()) {
                    if (rs.next()) {
                        String Username = rs.getString("Username");
                        String Password = rs.getString("password");

                        if(BCrypt.checkpw(password, Password)){
                            return true;
                        }
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }
}
