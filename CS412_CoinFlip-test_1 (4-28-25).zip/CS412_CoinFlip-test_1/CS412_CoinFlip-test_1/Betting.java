
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Betting extends JPanel {

    private JTextField Amount;
    private JTextField Result;
    private JButton SpinButton;
    private JPanel inputPanel;
    private JList choice;


    public Betting() {
        Amount = new JTextField(10);
        Result = new JTextField(10);
        String options[]= { "heads","tails"};
        choice = new JList(options);

        SpinButton = new JButton("spin!");

        inputPanel = new JPanel();
        inputPanel.add(choice);
        inputPanel.add(Amount);
        inputPanel.add(Result);


        setLayout(new BorderLayout());
        add(inputPanel, BorderLayout.CENTER);
        add(SpinButton, BorderLayout.SOUTH);
    }
    public String getChoice(){
        System.out.println("choice: " + choice.getSelectedValue().toString());
        return choice.getSelectedValue().toString();
    }
    public void addActionListnerButton(ActionListener listener) {
        SpinButton.addActionListener(listener);
    }

    public String getAmount() {
        return Amount.getText().trim();
    }

    public void setResult(String result) {
        Result.setText(result);
    }

}
