
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Controller {

    private View view;
    private create c;
    private Betting b;
    private login l;
    public Controller(View view) {
        this.view = view;
        l = view.getLoginPanel();
        c = view.getCreatePanel();
        b = view.getBetting();

        c.addActionListnerButton(new createTab());
        b.addActionListnerButton(new bettingTab());
        l.addActionListnerButton(new loginTab());
    }

    public class bettingTab implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            betting();
        }
    }

    public class loginTab implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            login();
        }
    }
    public class createTab implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            create();
        }
    }
    public void betting() {
        System.out.println("GOT HERE");
        String input = "Amount:" + b.getAmount();
        try (Socket socket = new Socket("localhost", 5001)) {
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            System.out.println("SENDING: " + input);
            out.println(input);

            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String response = in.readLine();

            b.setResult(response);
            System.out.println(response);

        } catch (IOException e) {
            System.out.println("FAILED to connect to server");
        }
    }

    public void create() {
        System.out.println("GOT HERE");
        String input = "Username: " + c.getUsername() +  " Password: " + c.getPassword();

        try (Socket socket = new Socket("localhost", 5001))
        {
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            System.out.println("SENDING: " + input);
            out.println(input);

            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String response = in.readLine();

            view.setjtextareaServer(response);

        } catch (IOException e) {
            System.out.println("FAILED to connect to server");
        }
    }

    public void login()
    {
        System.out.println("GOT HERE");
        String input = "login: " + l.getUsername() +  " Password: " + l.getPassword();

        try (Socket socket = new Socket("localhost", 5001))
        {
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            System.out.println("SENDING: " + input);
            out.println(input);

            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String response = in.readLine();

            view.setjtextareaServer(response);

        } catch (IOException e) {
            System.out.println("FAILED to connect to server");
        }
    }


}
