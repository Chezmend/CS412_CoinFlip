import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;

public class Game {

    public Game() {

    }

    public void update(int id, String username, String password, int amount) {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:database.db")) {
            String cmd = "UPDATE game SET amount = ? WHERE username = ?, password = ?";
            try (PreparedStatement cmdPre = conn.prepareStatement(cmd)) {
                cmdPre.setString(1, username);
                cmdPre.setString(2, password);
                cmdPre.setInt(3, amount);
                cmdPre.setInt(4, id);
                cmdPre.executeUpdate();
            } 
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public boolean Flip(){
        Random rand = new Random();
        int num = rand.nextInt(2);
        System.out.println(num);
        if(num == 1){
            return false;
        }
        else{
            return true;
        }
    }
}
